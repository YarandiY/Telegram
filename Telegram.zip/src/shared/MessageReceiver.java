package shared;

import java.io.Serializable;

public interface MessageReceiver extends Serializable {
}
